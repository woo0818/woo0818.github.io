This file contains the supplementary material for CVPR 2025, Paper ID 912.

We provide a supplementary PDF along with additional qualitative results, which are presented in a project-page format for convenience.

To access the additional qualitative results, please unzip the file into a folder and open the `index.html` file in a web browser. In most cases, double-clicking the `index.html` file will open it directly.

